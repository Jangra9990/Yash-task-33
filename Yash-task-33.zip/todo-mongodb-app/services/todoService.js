import Todo from "../models/todoModel.js";

const getAllTodos = async () => {
    return await Todo.find();
};

const createTodo = async (data) => {
    return await Todo.create(data);
};

const getTodoById = async (id) => {
    return await Todo.findById(id);
};

const updateTodo = async (id, data) => {
    return await Todo.findByIdAndUpdate(id, data, {
        new: true,
        runValidators: true
    });
};

const deleteTodo = async (id) => {
    return await Todo.findByIdAndDelete(id);
};

const searchTodos = async (query) => {
    return await Todo.find({
        title: { $regex: query, $options: "i" }
    });
};

export {
    getAllTodos,
    createTodo,
    getTodoById,
    updateTodo,
    deleteTodo,
    searchTodos
};