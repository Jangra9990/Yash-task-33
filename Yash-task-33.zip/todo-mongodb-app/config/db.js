
import mongoose from "mongoose";
import dns from "dns";

dns.setServers(["8.8.8.8", "8.8.4.4"]);

const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log("MongoDB Connected Successfully");
    } catch (error) {
    console.log("MongoDB Connection Failed:", error.message);

    if (error.reason?.servers) {
        for (const [address, server] of error.reason.servers) {
            console.log(
                address,
                server.error?.message || "No detailed server error"
            );
        }
    }

    process.exit(1);
}
};

export default connectDB;
