import { useEffect, useState } from "react";
import "./App.css";

const API = "http://localhost:5000/api/todos";

function App() {
    const [todos, setTodos] = useState([]);
    const [title, setTitle] = useState("");
    const [description, setDescription] = useState("");
    const [search, setSearch] = useState("");
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [editId, setEditId] = useState(null);

    const fetchTodos = async (query = "") => {
        try {
            setLoading(true);
            setError("");

            const url = query
                ? `${API}/search?q=${encodeURIComponent(query)}`
                : API;

            const response = await fetch(url);

            if (!response.ok) {
                throw new Error("Failed to fetch todos");
            }

            const data = await response.json();
            setTodos(data);
        } catch (err) {
            setError(err.message);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchTodos();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!title.trim()) {
            setError("Title is required");
            return;
        }

        try {
            setError("");

            const url = editId ? `${API}/${editId}` : API;
            const method = editId ? "PUT" : "POST";

            const response = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    title,
                    description
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Something went wrong");
            }

            setTitle("");
            setDescription("");
            setEditId(null);
            fetchTodos(search);
        } catch (err) {
            setError(err.message);
        }
    };

    const handleEdit = (todo) => {
        setTitle(todo.title);
        setDescription(todo.description);
        setEditId(todo._id);
    };

    const handleDelete = async (id) => {
        try {
            setError("");

            const response = await fetch(`${API}/${id}`, {
                method: "DELETE"
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to delete todo");
            }

            fetchTodos(search);
        } catch (err) {
            setError(err.message);
        }
    };

    const handleStatus = async (todo) => {
        try {
            setError("");

            const response = await fetch(`${API}/${todo._id}`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    status: todo.status === "completed"
                        ? "pending"
                        : "completed"
                })
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to update status");
            }

            fetchTodos(search);
        } catch (err) {
            setError(err.message);
        }
    };

    const handleSearch = (value) => {
        setSearch(value);
        fetchTodos(value);
    };

    return (
        <div>
            <h1>Todo List</h1>

            <form onSubmit={handleSubmit}>
                <input
                    type="text"
                    placeholder="Enter title"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                />

                <input
                    type="text"
                    placeholder="Enter description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                />

                <button type="submit">
                    {editId ? "Update Todo" : "Add Todo"}
                </button>

                {editId && (
                    <button
                        type="button"
                        onClick={() => {
                            setEditId(null);
                            setTitle("");
                            setDescription("");
                        }}
                    >
                        Cancel
                    </button>
                )}
            </form>

            <input
                type="text"
                placeholder="Search todos"
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
            />

            {loading && <p>Loading...</p>}

            {error && <p>{error}</p>}

            {!loading && todos.length === 0 && <p>No todos found</p>}

            {todos.map((todo) => (
                <div key={todo._id}>
                    <h3>{todo.title}</h3>
                    <p>{todo.description}</p>
                    <p>{todo.status}</p>

                    <button onClick={() => handleStatus(todo)}>
                        Change Status
                    </button>

                    <button onClick={() => handleEdit(todo)}>
                        Edit
                    </button>

                    <button onClick={() => handleDelete(todo._id)}>
                        Delete
                    </button>
                </div>
            ))}
        </div>
    );
}

export default App;