const errorMiddleware = (err, req, res, next) => {
    console.error(err);

    if (err.name === "ValidationError") {
        return res.status(400).json({
            message: err.message
        });
    }

    if (err.name === "CastError" || err.name === "BSONError") {
        return res.status(400).json({
            message: "Invalid ID"
        });
    }

    if (err.code === 11000) {
        return res.status(400).json({
            message: "Duplicate value"
        });
    }

    res.status(500).json({
        message: "Internal Server Error"
    });
};

export default errorMiddleware;