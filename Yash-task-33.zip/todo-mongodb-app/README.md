
Todo Application

A Todo application developed using React, Node.js, Express.js and MongoDB.

Features

Create todos
View todos
Update todos
Delete todos
Change todo status
Search todos

Technologies Used

React.js
Node.js
Express.js
MongoDB
Mongoose
CSS

Backend Setup

Open the project folder
Install dependencies using npm install
Add MongoDB connection details in the .env file
Run the backend using npm run dev

Frontend Setup

Open the client folder
Install dependencies using npm install
Run the frontend using npm run dev

API Endpoints

GET /api/todos
POST /api/todos
GET /api/todos/:id
PUT /api/todos/:id
DELETE /api/todos/:id
GET /api/todos/search?q=keyword

Author
Yash