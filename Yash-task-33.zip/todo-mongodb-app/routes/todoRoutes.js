import express from "express";

import {
    getTodos,
    createTodo,
    getTodo,
    updateTodo,
    deleteTodo,
    searchTodos
} from "../controllers/todoController.js";

const router = express.Router();

router.get("/", getTodos);
router.post("/", createTodo);
router.get("/search", searchTodos);
router.get("/:id", getTodo);
router.put("/:id", updateTodo);
router.delete("/:id", deleteTodo);

export default router;