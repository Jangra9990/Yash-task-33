import * as todoService from "../services/todoService.js";

const getTodos = async (req, res, next) => {
    try {
        const todos = await todoService.getAllTodos();
        res.status(200).json(todos);
    } catch (error) {
        next(error);
    }
};

const createTodo = async (req, res, next) => {
    try {
        const todo = await todoService.createTodo(req.body);
        res.status(201).json(todo);
    } catch (error) {
        next(error);
    }
};

const getTodo = async (req, res, next) => {
    try {
        const todo = await todoService.getTodoById(req.params.id);

        if (!todo) {
            return res.status(404).json({ message: "Todo not found" });
        }

        res.status(200).json(todo);
    } catch (error) {
        next(error);
    }
};

const updateTodo = async (req, res, next) => {
    try {
        const todo = await todoService.updateTodo(req.params.id, req.body);

        if (!todo) {
            return res.status(404).json({ message: "Todo not found" });
        }

        res.status(200).json(todo);
    } catch (error) {
        next(error);
    }
};

const deleteTodo = async (req, res, next) => {
    try {
        const todo = await todoService.deleteTodo(req.params.id);

        if (!todo) {
            return res.status(404).json({ message: "Todo not found" });
        }

        res.status(200).json({ message: "Todo deleted successfully" });
    } catch (error) {
        next(error);
    }
};

const searchTodos = async (req, res, next) => {
    try {
        const todos = await todoService.searchTodos(req.query.q || "");
        res.status(200).json(todos);
    } catch (error) {
        next(error);
    }
};

export {
    getTodos,
    createTodo,
    getTodo,
    updateTodo,
    deleteTodo,
    searchTodos
};